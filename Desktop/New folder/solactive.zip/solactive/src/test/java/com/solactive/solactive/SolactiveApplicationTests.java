package com.solactive.solactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
